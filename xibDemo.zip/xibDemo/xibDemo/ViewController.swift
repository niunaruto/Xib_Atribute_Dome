//
//  ViewController.swift
//  xibDemo
//
//  Created by Macbook1 on 2019/6/21.
//  Copyright © 2019 naruto. All rights reserved.
//

import UIKit
import SnapKit
class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.asyncAfter(deadline:.now() + 3) {
            self.label.snp.updateConstraints({ (make) in
                make.left.equalToSuperview().offset(20*pointRatio)
                make.top.equalToSuperview().offset(200*pointRatio)
            })
        }
    }
}

