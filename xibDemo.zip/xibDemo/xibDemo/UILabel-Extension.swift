//
//  UILabel-Extension.swift
//  xibDemo
//
//  Created by Macbook1 on 2019/6/21.
//  Copyright © 2019 naruto. All rights reserved.
//

import UIKit
var fontnameKey = "101"

extension UILabel {
    
    @IBInspectable var fontname: String {
        set {
            objc_setAssociatedObject(self, &fontnameKey, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_COPY_NONATOMIC)
            self.font = UIFont.init(name: fontname, size: self.font.pointSize)

        }
        get {
            if let fontname = objc_getAssociatedObject(self, &fontnameKey) as? String {
                return fontname
            }
            return ""
        }
    }
    
}
